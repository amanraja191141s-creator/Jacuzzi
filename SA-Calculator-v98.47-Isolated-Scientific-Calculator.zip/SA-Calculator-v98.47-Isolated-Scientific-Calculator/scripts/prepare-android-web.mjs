import { cp, mkdir, rm, access, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'www');
const cssSources = ['assets/css/app-base.css', 'assets/css/rebuild-v98.32.css', 'assets/css/rebuild-v98.33.css', 'assets/css/rebuild-v98.35.css', 'assets/css/rebuild-v98.37.css', 'assets/css/rebuild-v98.38.css', 'assets/css/rebuild-v98.39.css', 'assets/css/rebuild-v98.40.css', 'assets/css/rebuild-v98.41.css', 'assets/css/rebuild-v98.44.css', 'assets/css/rebuild-v98.45.css', 'assets/css/rebuild-v98.46.css', 'assets/css/rebuild-v98.47.css'];
const required = ['index.html', ...cssSources, 'assets/css/app.css', 'assets/js/app.js', 'assets/js/localization.js', 'assets/js/currency-localized-names.js', 'assets/js/theme-bootstrap.js', 'assets/brand/sa-calculator-icon.png', 'assets/brand/sa-calculator-192.png', 'assets/brand/sa-calculator-512.png', 'service-worker.js'];
for (const item of required) {
  try { await access(path.join(root, item)); }
  catch { throw new Error(`Required app asset is missing: ${item}`); }
}
const cssParts = [];
for (const source of cssSources) cssParts.push(`\n/* ===== Consolidated source: ${source} ===== */\n`, await readFile(path.join(root, source), 'utf8'));
await writeFile(path.join(root, 'assets/css/app.css'), cssParts.join(''));
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
for (const item of ['index.html', 'manifest.webmanifest', 'service-worker.js', 'assets']) {
  await cp(path.join(root, item), path.join(out, item), { recursive: true });
}
// Keep the registered offline worker beside index.html in the Capacitor web root.
await access(path.join(out, 'service-worker.js'));
console.log(`Android web bundle prepared: ${required.length} required assets verified; ${cssSources.length} CSS layers consolidated into one app.css request.`);
