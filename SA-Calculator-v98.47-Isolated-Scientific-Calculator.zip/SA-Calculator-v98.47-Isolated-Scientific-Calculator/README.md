# SA Calculator v98.47 — Independent Scientific Calculator Rebuild

Release: `1.98.47-v98.47`  
Android versionCode: `1098047`

## What changed

- Removed the scientific-functions modal and every basic-calculator entry point to it.
- Removed the basic calculator's scientific shortcut, power shortcut, DEG/RAD control, and shared memory controls. Its keypad is now the basic 19-key arithmetic keypad only.
- Added a standalone `screen-scientific` destination in the Tools menu with its own expression editor, result lane, function panel, numeric/operator keypad, DEG/RAD switch, memory, ANS and history.
- Scientific expression, result, angle, memory and history are held in a separate `sci` state and independent local-storage keys. The scientific UI does not read or write `STATE.calcExpr`, `STATE.calcVal`, basic calculator selection, or basic memory.
- The shared arithmetic parser accepts an explicit angle mode. The Scientific screen always passes its own DEG/RAD value; no global basic-calculator angle setting remains.
- Added persistent scientific history (last 50 entries), tap-to-restore, clear history, ANS, MC/MR/M+/M−/MS, π/e, powers, roots, factorial, reciprocal, abs, log/log₂/ln, trig/inverse trig and hyperbolic functions.
- Added a responsive standalone scientific layout and included its CSS in the production Android web bundle and Service Worker release cache.

## Build and test

```bash
npm test
npm run build:web
```

The Android GitHub Actions workflow is `.github/workflows/main.yml`; the matching downloadable copy is `SA-Calculator-v98.47-Android-Workflow.yml`.

## Verification limits

The source test suite and generated web bundle can be verified in this workspace. A hosted Android APK build and installation/visual/performance tests on a physical Android device are not claimed as completed here.
