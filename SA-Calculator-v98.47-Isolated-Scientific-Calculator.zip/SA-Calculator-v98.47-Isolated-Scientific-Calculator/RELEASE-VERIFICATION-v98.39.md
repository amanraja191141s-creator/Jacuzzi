# SA Calculator v98.39 — Release verification

## Source basis
- Exact source archive: SA Calculator v98.38 Premium System Rebuild
- User-supplied Android screenshot: Screenshot_20261117_175644.jpg

## Screenshot-led corrections
- Touch-focused skip link is visually clipped on touch-only focus while remaining keyboard-focusable with `:focus-visible`.
- Calculator expression/result display has no outer border, outline, shadow or decorative frame.
- Calculator flex sizing and bottom navigation no longer reserve the excessive internal bottom safe-area padding visible in the screenshot.
- Scientific Calculator is a searchable drawer entry and launches the existing tested scientific calculator dialog/engine.
- Currency and Unit Converter keypad utility actions use concise icons and AC, with accessible labels and original action semantics retained.

## Automated validation
- `node --check assets/js/app.js`: PASS
- `node --check scripts/prepare-android-web.mjs`: PASS
- `npm run build:web`: PASS; 17 required runtime assets verified and copied
- `node --test tests/*.test.js tests/*.test.mjs`: 279 passed, 0 failed
- YAML parsing: PASS for active workflow and delivered workflow
- JSON parsing: PASS for package, manifest and Capacitor configuration
- ZIP integrity: checked after packaging

## Not claimed
A hosted Android APK build and physical-device installation/visual/touch/performance run have not been performed in this environment. No claim of absolute lag-free or bug-free behavior is made until those checks are completed.
