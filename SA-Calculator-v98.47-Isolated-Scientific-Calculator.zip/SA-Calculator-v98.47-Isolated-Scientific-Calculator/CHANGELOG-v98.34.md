# Changelog — v98.35

## Physical UI cleanup from 17 November 2026 recording
- Removed any global app-header layout footprint while a tool screen is active.
- Stabilized tool toolbar and scroll viewport flex sizing, clipping and opaque background.
- Corrected Sales Tax percentage suffix double-border appearance.
- Constrained Currency Converter selector width and overflow.
- Improved Quick Guide scroll/footer behavior on compact screens.
- Added four targeted physical-video regression tests.

## Preserved
- All calculator engines, all 18 destinations, currency provider/cache behavior, localization, themes, settings, favorites, history, keyboard flows, and Android branding/build pipeline.

## Release identity
- App version: `1.98.36-v98.36`
- Android versionCode: `1098036`
