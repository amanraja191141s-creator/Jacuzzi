'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'assets/js/app.js'), 'utf8');
function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `${name} not found`);
  const signatureEnd = source.indexOf(')', start);
  const open = source.indexOf('{', signatureEnd);
  function skipQuoted(i, quote) {
    i++;
    while (i < source.length) {
      if (source[i] === '\\') { i += 2; continue; }
      if (source[i] === quote) return i + 1;
      i++;
    }
    return i;
  }
  function skipTemplate(i) {
    i++;
    while (i < source.length) {
      if (source[i] === '\\') { i += 2; continue; }
      if (source[i] === '`') return i + 1;
      if (source[i] === '$' && source[i + 1] === '{') {
        i = skipCodeBlock(i + 1);
        continue;
      }
      i++;
    }
    return i;
  }
  function skipCodeBlock(brace) {
    let depth = 1, i = brace + 1;
    while (i < source.length && depth > 0) {
      const ch = source[i];
      if (ch === "'" || ch === '"') { i = skipQuoted(i, ch); continue; }
      if (ch === '`') { i = skipTemplate(i); continue; }
      if (ch === '/' && source[i + 1] === '/') {
        i += 2; while (i < source.length && source[i] !== '\n') i++; continue;
      }
      if (ch === '/' && source[i + 1] === '*') {
        i += 2; while (i < source.length && !(source[i] === '*' && source[i + 1] === '/')) i++; i += 2; continue;
      }
      if (ch === '{') depth++;
      else if (ch === '}') depth--;
      i++;
    }
    return i;
  }
  const close = skipCodeBlock(open);
  if (close <= open + 1 || source[close - 1] !== '}') throw new Error(`Could not extract ${name}`);
  return source.slice(start, close);
}
function engine(extraState = {}) {
  const context = {
    STATE: { implicitMult: true, calcScientificContinuation: null,
      calcScientificErrorPreview: false, calcScientificErrorExpression: null, ...extraState },
    Math, Number, String, Set, Error,
    normalizeStandaloneScientificEntry: value => String(value ?? ''),
    formatCalculatorExpressionResult: (_expression, value) => String(value)
  };
  const names = [
    'normalizeScientificExpressionGlyphs', 'normalizedCalcExpression', 'evaluateArithmetic',
    'isForcedScientificErrorPreview', 'calculatorExpressionHasDefiniteSyntaxError',
    'hasBinaryCalculatorOperator', 'hasPreviewableCalculatorOperation',
    'isLivePreviewIncompleteExpression', 'evaluateLiveExpression'
  ];
  for (const name of names) { try { new vm.Script(extract(name)); } catch (error) { throw new Error(`${name}: ${error.message}\n${extract(name).slice(-240)}`); } }
  vm.runInNewContext(`${names.map(extract).join('\n')};\n` +
    'globalThis.normalized=normalizedCalcExpression;globalThis.calc=evaluateArithmetic;' +
    'globalThis.preview=evaluateLiveExpression;', context);
  return context;
}

test('scientific display token inside a radical resolves to the exact committed value', () => {
  const exact = 98 ** 9;
  const token = '8.337478 × 10¹⁷';
  const c = engine({ calcScientificContinuation: { displayToken: token, exactValue: exact } });
  const normalized = c.normalized(`√(${token})`);
  assert.equal(normalized, `√(${String(exact)})`);
  const actual = c.calc(normalized);
  assert.ok(Math.abs(actual - Math.sqrt(exact)) < 1e-6);
});

test('valid radical preview is evaluated instead of being forced to Error', () => {
  const exact = 98 ** 9;
  const token = '8.337478 × 10¹⁷';
  const c = engine({ calcScientificContinuation: { displayToken: token, exactValue: exact } });
  const expression = `√(${token})`;
  const normalized = c.normalized(expression);
  const expected = Math.sqrt(exact);
  assert.equal(Number(c.preview(expression)), expected);
  assert.notEqual(c.preview(expression), 'Error');
  assert.equal(c.calc(normalized), expected);
});

test('editing the scientific display token invalidates exact-value continuation metadata', () => {
  const token = '8.337478 × 10¹⁷';
  const c = engine({ calcScientificContinuation: { displayToken: token, exactValue: 98 ** 9 } });
  c.normalized('√(8.337479 × 10¹⁷)');
  assert.equal(c.STATE.calcScientificContinuation, null);
});

test('integer powers inside Number range stay precise and overflow is rejected, never shown as a false finite result', () => {
  const c = engine();
  assert.equal(c.calc('9^99'), 9 ** 99);
  assert.throws(() => c.calc('9^999'));
  assert.throws(() => c.calc('9^9999'));
});


test('cube root evaluates an overflowing power through its finite final result', () => {
  const c = engine();
  const actual = c.calc('∛9^966');
  const expected = 9 ** 322;
  assert.ok(Number.isFinite(actual));
  assert.ok(Math.abs(actual / expected - 1) < 1e-12);
  assert.notEqual(c.preview('∛9^966'), 'Error');
  assert.ok(Number.isFinite(Number(c.preview('∛9^966'))));
  assert.throws(() => c.calc('∛9^999'));
});

test('radical power optimization preserves negative cube-root sign and square-root domain', () => {
  const c = engine();
  assert.equal(c.calc('∛-9^3'), -9);
  assert.throws(() => c.calc('√-9^2'));
});

test('parenthesized radical powers avoid intermediate overflow when the final root is finite', () => {
  const c = engine();
  const cube = c.calc('∛(9^966)');
  const cubeExpected = 9 ** 322;
  assert.ok(Number.isFinite(cube));
  assert.ok(Math.abs(cube / cubeExpected - 1) < 1e-12);
  const square = c.calc('√(9^324)');
  const squareExpected = 9 ** 162;
  assert.ok(Number.isFinite(square));
  assert.ok(Math.abs(square / squareExpected - 1) < 1e-12);
  assert.equal(c.calc('√((-9)^2)'), 9);
  assert.throws(() => c.calc('∛(9^999)'));
  assert.notEqual(c.preview('∛(9^966)'), 'Error');
});

test('scientific UI no longer contains a bridge that mutates basic calculator expression state', () => {
  const start = source.indexOf('function initScientific()');
  const end = source.indexOf('const CURRENCY_CATALOG', start);
  const init = source.slice(start, end);
  assert.doesNotMatch(init, /STATE\.calcExpr|STATE\.calcVal|setCalcEditorSelection/);
  assert.match(init, /sci\.expression/);
  assert.match(init, /sci\.history/);
  assert.match(init, /sci\.memory/);
});

test('scientific continuation preview keeps the scientific token after a trailing operator', () => {
  const formatSource = [
    extract('toSuperscriptExponent'),
    extract('formatScientificEntryDisplay'),
    extract('formatCalculatorExpressionResult')
  ].join('\n');
  const context = {
    Number, String, Math,
    STATE: { thousandsSep: 'lakh' },
    isScientificEntryExpression: () => false,
    formatCalculatorResultNumber: value => `ordinary:${value}`,
    formatResultNumber: value => String(value)
  };
  vm.runInNewContext(`${formatSource}\nglobalThis.format=formatCalculatorExpressionResult;`, context);
  assert.equal(context.format('1×10⁹×', 1e9), 'ordinary:1000000000');
  assert.equal(context.format('1×10⁹×2', 2e9), 'ordinary:2000000000');
  assert.equal(context.format('1×10⁹+2', 1000000002), 'ordinary:1000000002'); // 12-digit threshold; raw arithmetic value remains exact
});

test('scientific continuation display does not change the numeric result', () => {
  const formatSource = [
    extract('toSuperscriptExponent'),
    extract('formatScientificEntryDisplay'),
    extract('formatCalculatorExpressionResult')
  ].join('\n');
  const context = {
    Number, String, Math,
    STATE: { thousandsSep: 'lakh' },
    isScientificEntryExpression: () => false,
    formatCalculatorResultNumber: value => `ordinary:${value}`,
    formatResultNumber: value => String(value)
  };
  vm.runInNewContext(`${formatSource}\nglobalThis.format=formatCalculatorExpressionResult;`, context);
  const display = context.format('1×10⁹×2', 2e9);
  assert.equal(display, 'ordinary:2000000000');
  assert.equal(Number(2e9), 2000000000);
});
